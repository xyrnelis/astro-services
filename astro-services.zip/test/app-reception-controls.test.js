import { readFileSync } from 'node:fs';
import { it } from 'node:test';
import assert from 'node:assert/strict';
import { JSDOM } from 'jsdom';
import { initializeApp } from '../src/ui/app.js';

function appDocument() {
  const html = readFileSync(new URL('../index.html', import.meta.url), 'utf8');
  const dom = new JSDOM(html, { url: 'https://example.test/' });
  initializeApp(dom.window.document);
  return dom.window;
}

it('opens reception help without changing disabled controls and dismisses it accessibly', () => {
  const window = appDocument();
  const { document } = window;
  const toggle = document.querySelector('#reception-steps-toggle');
  const help = document.querySelector('[data-reception-help="steps"]');
  const popover = document.querySelector('#reception-help-steps');

  assert.equal(toggle.disabled, true);
  help.click();
  assert.equal(toggle.checked, true);
  assert.equal(popover.hidden, false);
  assert.equal(help.getAttribute('aria-expanded'), 'true');
  document.body.dispatchEvent(new window.MouseEvent('click', { bubbles: true }));
  assert.equal(popover.hidden, true);
  help.dispatchEvent(new window.FocusEvent('focus'));
  assert.equal(popover.hidden, false);
  document.dispatchEvent(new window.KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
  assert.equal(popover.hidden, true);
});

it('resets and disables option 4 when option 3 is switched off', () => {
  const window = appDocument();
  const { document } = window;
  const main = document.querySelector('#reception-toggle');
  const signs = document.querySelector('#reception-signs-toggle');
  const conjunctions = document.querySelector('#reception-conjunctions-toggle');

  main.disabled = false;
  main.checked = true;
  main.dispatchEvent(new window.Event('change', { bubbles: true }));
  signs.checked = true;
  signs.dispatchEvent(new window.Event('change', { bubbles: true }));
  assert.equal(conjunctions.disabled, false);
  conjunctions.checked = true;
  signs.checked = false;
  signs.dispatchEvent(new window.Event('change', { bubbles: true }));
  assert.equal(conjunctions.checked, false);
  assert.equal(conjunctions.disabled, true);
});
